const GPS_METAS_INICIAIS = [
  ['Desenvolvimento Curricular', 'visita', 'semana', 2, false, true],
  ['Desenvolvimento Curricular', 'apoio', 'quinzena', 2, false, true],
  ['Qualidade da Aula', 'visita', 'quinzena', 1, true, true],
  ['Qualidade da Aula', 'apoio', 'quinzena', 1, true, true],
  ['Educação Especial', 'visita', 'semana', 2, false, true],
  ['Multiplica', 'visita', 'semana', 2, false, true],
  ['Recomposição', 'visita', 'quinzena', 1, true, false]
].map(([pasta, atividade, periodicidade, quantidade, por_escola, obrigatoria]) =>
  ({ pasta, atividade, periodicidade, quantidade, por_escola, obrigatoria }));

function gpsDataValida_(data) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return false;
  const valor = new Date(data + 'T00:00:00Z');
  return Number.isFinite(valor.getTime()) && valor.toISOString().slice(0, 10) === data;
}

function gpsConsolidarAgenda_(linhas) {
  const atividades = new Map();
  const revisoes = [];
  for (const linha of linhas) {
    if (linha.tabelaConteiner || linha.tipo === 'interna') continue;
    const escolas = [...new Set((linha.escolas || []).filter(Boolean))];
    if (!linha.pec_id || !gpsDataValida_(linha.data) || !escolas.length ||
        !['visita', 'apoio'].includes(linha.tipo)) {
      revisoes.push({ origem: linha.origem, motivo: 'atividade_indeterminada' });
      continue;
    }
    for (const escola_id of escolas) {
      const id = gpsChave_(linha.tipo, linha.pec_id, linha.data, escola_id, linha.horario || '');
      if (!atividades.has(id)) {
        atividades.set(id, {
          id, escola_id, data: linha.data, pec_id: linha.pec_id, tipo: linha.tipo,
          horario: linha.horario || '', turma_id: linha.turma_id, componente_id: linha.componente_id,
          origens: [linha.origem]
        });
        continue;
      }
      const registro = atividades.get(id);
      if (registro.turma_id !== linha.turma_id || registro.componente_id !== linha.componente_id) {
        revisoes.push({ id, origem: linha.origem, motivo: 'atividades_conflitantes' });
      }
      if (!registro.origens.includes(linha.origem)) registro.origens.push(linha.origem);
    }
  }
  return { atividades: Array.from(atividades.values()), revisoes };
}

function gpsCruzarVisitas_(atividades, comprovantes, hoje) {
  if (!gpsDataValida_(hoje)) throw new Error('Data de referência inválida');
  const documentos = new Map();
  for (const documento of comprovantes) {
    if (!documento.validado || !['ficha_visita', 'termo_visita'].includes(documento.tipo)) continue;
    const tipos = documentos.get(documento.visita_id) || new Set();
    tipos.add(documento.tipo);
    documentos.set(documento.visita_id, tipos);
  }
  const unicas = Array.from(new Map(atividades.map(atividade => [atividade.id, atividade])).values());
  return unicas.map(atividade => {
    const contabilizada = atividade.data <= hoje && atividade.status !== 'cancelada';
    const tipos = documentos.get(atividade.id) || new Set();
    const comprovada = contabilizada && tipos.size > 0;
    return {
      ...atividade, contabilizada, comprovada, pendenciaDocumental: contabilizada && atividade.tipo === 'visita' && tipos.size < 2,
      aguardandoTermo: contabilizada && atividade.tipo === 'visita' && !tipos.has('termo_visita'),
      situacao: atividade.status === 'cancelada' ? 'cancelada' :
        !contabilizada ? 'prevista' : comprovada ? 'comprovada' : 'aguardando_comprovacao'
    };
  });
}

function gpsAvaliarMeta_(regra, atividades, pec_id, periodo, escola_id) {
  if (!gpsDataValida_(periodo.inicio) || !gpsDataValida_(periodo.fim) ||
      periodo.inicio > periodo.fim || !gpsDataValida_(periodo.hoje) ||
      (regra.por_escola && !escola_id)) throw new Error('Escopo da meta inválido');
  const itens = new Map(atividades.filter(item =>
    item.pec_id === pec_id && item.tipo === regra.atividade && item.status !== 'cancelada' &&
    item.data >= periodo.inicio && item.data <= periodo.fim &&
    (!regra.por_escola || item.escola_id === escola_id)).map(item => [item.id, item]));
  const registros = [...itens.values()];
  const planejamentoContabilizado = registros.filter(item => item.contabilizada).length;
  const comprovado = registros.filter(item => item.comprovada).length;
  return {
    previsto: registros.length, planejamentoContabilizado, comprovado,
    meta: regra.quantidade, obrigatoria: regra.obrigatoria,
    pendente: regra.obrigatoria && periodo.hoje > periodo.fim && planejamentoContabilizado < regra.quantidade
  };
}

function gpsMonitorarPrioridades_(prioridades, atividades) {
  const porEscola = new Map();
  for (const atividade of atividades) {
    if (atividade.status === 'cancelada') continue;
    const chave = gpsChave_(atividade.escola_id, atividade.data.slice(0, 4));
    if (!porEscola.has(chave)) porEscola.set(chave, []);
    porEscola.get(chave).push(atividade);
  }
  return prioridades.map(prioridade => {
    const candidatas = porEscola.get(gpsChave_(prioridade.escola_id, String(prioridade.ano))) || [];
    const alinhadas = candidatas.filter(item =>
      (!prioridade.turma_id || item.turma_id === prioridade.turma_id) &&
      (!prioridade.componente_id || item.componente_id === prioridade.componente_id));
    return {
      prioridade_id: prioridade.id,
      quantidade: alinhadas.length,
      direcionamento: !candidatas.length ? 'sem_planejamento' :
        alinhadas.length ? 'alinhado' : 'divergente',
      intencionalidade: 'requer_revisao_pedagogica',
      evidencias: alinhadas.some(item => item.comprovada) ? 'comprovado' :
        alinhadas.some(item => item.contabilizada) ? 'sem_evidencia_documental' : 'pendente',
      efetividade: 'requer_avaliacao_pedagogica'
    };
  });
}
const GPS_LAYOUT_BOLETINS = {
  saresp: {
    ano: ['ano', 'ano de aplicacao', 'edicao'],
    nota: ['nota', 'nota media'],
    proficiencia: ['proficiencia', 'proficiencia media'],
    participacao: ['participacao', 'taxa de participacao']
  },
  saeb: {
    ano: ['ano', 'ano de aplicacao', 'edicao saeb'],
    proficiencia: ['proficiencia', 'proficiencia media', 'media de desempenho'],
    participacao: ['participacao', 'taxa de participacao'],
    percentual_nivel: ['percentual no nivel', 'percentual por nivel']
  }
};

function gpsSerieBoletim_(original) {
  const texto = gpsNormalizar_(original);
  if (/^(ef[1-9]|em[1-3])$/.test(texto)) return texto.toUpperCase();
  const resultado = texto.match(/^([1-9])\s*[ºª°o.]?\s*(ano(?: do ensino fundamental)?|serie do ensino medio)$/);
  if (!resultado) return '';
  if (resultado[2].startsWith('serie')) return Number(resultado[1]) <= 3 ? 'EM' + resultado[1] : '';
  return 'EF' + resultado[1];
}

function gpsExtrairBoletim_(documento, fonte, documento_id) {
  const perfil = GPS_LAYOUT_BOLETINS[fonte];
  if (!perfil || !documento_id) throw new Error('Boletim sem contexto');
  const indicadores = [];
  const revisoes = [];
  const grades = documento.grades || [];
  for (const [tabela, grade] of grades.entries()) {
    if (grade.some(linha => linha.some(celula => /^(cpf|rg|ra|nome do aluno|nome do estudante)$/.test(gpsNormalizar_(celula))))) {
      revisoes.push({ tabela, motivo: 'dados_individuais_bloqueados' });
      continue;
    }
    const base = { ano: perfil.ano, serie: ['ano/serie', 'serie', 'etapa'],
      escola: ['codigo escola', 'codigo da escola', 'codigo seduc', 'codigo inep'],
      componente: ['componente', 'componente curricular', 'disciplina'] };
    for (const [metrica, nomes] of Object.entries(perfil)) {
      if (metrica === 'ano') continue;
      const aliases = { ...base, valor: nomes };
      if (metrica === 'percentual_nivel') aliases.nivel = ['nivel', 'nivel de proficiencia'];
      const cabecalhos = gpsDetectarCabecalho_(grade, aliases);
      for (const [i, cabecalho] of cabecalhos.entries()) {
        const fim = cabecalhos[i + 1]?.linha ?? grade.length;
        const { campos } = cabecalho;
        for (let linha = cabecalho.linha + 1; linha < fim; linha++) {
          const valores = grade[linha];
          if (!valores.some(item => String(item ?? '').trim())) continue;
          const ler = campo => String(valores[campos[campo]] ?? '').trim();
          const ano = Number(ler('ano'));
          const serie = gpsSerieBoletim_(ler('serie'));
          const escola_id = ler('escola');
          const componente_id = ler('componente');
          const nivel = ler('nivel');
          const percentual = ['participacao', 'percentual_nivel'].includes(metrica);
          const resultado = gpsValorAvaliacao_(ler('valor'), percentual ? 'percentual' : metrica);
          if (!/^\d{4}$/.test(ler('ano')) || (fonte === 'saeb' && ano % 2 !== 1) || !serie ||
              !escola_id || !componente_id || (aliases.nivel && !nivel)) {
            revisoes.push({ tabela, linha: linha + 1, motivo: 'rotulo_valor_ou_escala_indeterminados' });
            continue;
          }
          if (resultado.revisar) revisoes.push({ tabela, linha: linha + 1, motivo: 'valor_requer_conferencia' });
          // A versão identifica a métrica e a edição sem inferir equivalência entre boletins.
          const escala = [fonte, metrica, ano].join(':');
          indicadores.push({
            id: gpsChave_(documento_id, fonte, ano, escola_id, serie, componente_id, metrica, nivel),
            ano, periodo: String(ano), escola_id, serie, componente_id, metrica, escala, nivel,
            documento_id, fonte, valor_original: resultado.original, valor: resultado.valor, revisar: resultado.revisar
          });
        }
      }
    }
  }
  const porId = new Map();
  const duplicados = new Set();
  for (const item of indicadores) {
    if (porId.has(item.id)) duplicados.add(item.id);
    porId.set(item.id, item);
  }
  if (duplicados.size) revisoes.push({ motivo: 'rotulo_repetido_ou_conflitante' });
  if (!porId.size) revisoes.push({ motivo: 'sem_tabela_identificavel' });
  if ((documento.imagens || []).some(item => item.revisar)) revisoes.push({ motivo: 'ocr_requer_conferencia' });
  return { indicadores: [...porId.values()].filter(item => !duplicados.has(item.id)), revisoes };
}

function gpsRecuperarImagensExportadas_(id, imagens, pastaId) {
  if (!imagens.some(item => item.motivo === 'image_id_invalido')) return imagens;
  try {
    const zip = Drive.Files.export(id, 'application/zip');
    const arquivos = Utilities.unzip(zip);
    const html = arquivos.find(item => /\.html?$/i.test(item.getName()));
    const caminhos = [...(html?.getDataAsString('UTF-8') || '').matchAll(/<img\b[^>]*?\bsrc=["']([^"']+)["']/gi)]
      .map(item => item[1].replace(/^\.\//, ''));
    if (caminhos.length !== imagens.length || new Set(caminhos).size !== caminhos.length) return imagens;
    const porNome = new Map(arquivos.map(item => [item.getName(), item]));
    return imagens.map((item, i) => {
      const blob = porNome.get(caminhos[i]);
      if (item.motivo !== 'image_id_invalido' || !blob ||
          !/\.(png|jpe?g|gif|bmp|webp)$/i.test(caminhos[i])) return item;
      try {
        const texto = gpsOCRBlob_(blob, pastaId).trim();
        return texto ? { ...item, texto, motivo: 'ocr_exportado_ordem_requer_conferencia' } : item;
      } catch {
        return item;
      }
    });
  } catch {
    return imagens;
  }
}
const GPS_SCHEMA = {
  municipios: ['nome'], escolas: ['municipio_id', 'codigo', 'nome', 'latitude', 'longitude'],
  pecs: ['nome'], pastas: ['nome'], anos_letivos: ['ano'],
  atribuicoes: ['pec_id', 'pasta_id', 'escola_id', 'ano_letivo_id'],
  turmas: ['escola_id', 'ano_letivo_id', 'serie', 'codigo'],
  componentes: ['nome'], planos: ['pec_id', 'documento_id', 'periodo', 'objetivo'],
  visitas: ['plano_id', 'pec_id', 'escola_id', 'turma_id', 'componente_id', 'data', 'status', 'horario', 'pasta_id'],
  apoios: ['plano_id', 'pec_id', 'escola_id', 'turma_id', 'componente_id', 'data', 'status', 'horario', 'pasta_id'],
  documentos: ['chave', 'tipo', 'versao', 'origem'],
  comprovantes: ['visita_id', 'documento_id', 'tipo', 'validado', 'observacao'],
  indicadores: ['escola_id', 'municipio_id', 'turma_id', 'componente_id', 'ano', 'serie', 'fonte', 'periodo', 'metrica', 'escala', 'nivel', 'valor_original', 'valor', 'revisar', 'documento_id'],
  metas: ['pasta_id', 'atividade', 'periodicidade', 'quantidade', 'por_escola', 'obrigatoria'],
  prioridades: ['escola_id', 'turma_id', 'componente_id', 'ano', 'serie', 'criterio_versao', 'indicador_id', 'referencias_historicas', 'referencias_escola', 'diagnostico'],
  alertas: ['prioridade_id', 'visita_id', 'tipo', 'status', 'criticidade', 'destinatario_id', 'periodo', 'alvo_id', 'ultima_notificacao', 'ocorrencias', 'envio'],
  justificativas: ['visita_id', 'motivo', 'status', 'alerta_id', 'pec_id'],
  encaminhamentos: ['alerta_id', 'acao', 'prazo', 'status'],
  revisoes: ['documento_id', 'motivo', 'status'],
  escopos_at: ['usuario_id', 'escola_id'],
  usuarios: ['email', 'perfil', 'pec_id', 'ativo'],
  fila: ['documento_id', 'origem', 'status', 'tentativas', 'versao'],
  calendario_dias: ['data', 'util', 'referencia', 'homologado'],
  obrigacoes_documentais: ['pec_id', 'tipo', 'prazo', 'entrega', 'aplicavel', 'homologado', 'referencia'],
  decisoes_visita: ['visita_id', 'pec_id', 'decisao', 'motivo', 'instante'],
  farois: ['fonte', 'ano', 'escala', 'metrica', 'nivel', 'cor', 'referencia', 'homologado'],
  criterios: ['fonte', 'metrica', 'escala', 'nivel', 'direcao', 'limite', 'versao', 'aprovado_cec'],
  fontes_importacao: ['origem', 'fonte', 'escala', 'metrica', 'unidade', 'periodo'],
  termos_web: ['visita_id', 'pec_id', 'tipo', 'observacao'],
  auditoria: ['entidade', 'registro_id', 'operacao', 'instante', 'ator_id']
};

const GPS_RELACOES = {
  municipio_id: 'municipios', escola_id: 'escolas', pec_id: 'pecs', pasta_id: 'pastas',
  ano_letivo_id: 'anos_letivos', turma_id: 'turmas', componente_id: 'componentes',
  documento_id: 'documentos', plano_id: 'planos', visita_id: 'visitas',
  prioridade_id: 'prioridades', alerta_id: 'alertas', indicador_id: 'indicadores'
};

function gpsChave_(...partes) {
  return JSON.stringify(partes);
}

function gpsValidarRegistro_(tabela, registro, indice) {
  if (!Object.prototype.hasOwnProperty.call(GPS_SCHEMA, tabela) || !registro.id) {
    throw new Error('Tabela ou ID inválido');
  }
  const anterior = indice[tabela]?.get(registro.id);
  const chaves = ['id', ...GPS_SCHEMA[tabela]];
  if (anterior && chaves.some(campo => (anterior[campo] ?? '') !== (registro[campo] ?? ''))) {
    throw new Error('Conflito para o mesmo ID');
  }
  if (tabela === 'documentos' && registro.chave &&
      Array.from(indice.documentos?.values() ?? []).some(item =>
        item.id !== registro.id && item.chave === registro.chave && item.versao === registro.versao)) {
    throw new Error('Documento duplicado');
  }
  for (const campo of GPS_SCHEMA[tabela]) {
    const destino = GPS_RELACOES[campo];
    if (destino && registro[campo] && !indice[destino]?.has(registro[campo])) {
      throw new Error('Referência ausente: ' + campo);
    }
  }
  return !anterior;
}

// Execute manualmente apenas no projeto de laboratório, com a planilha isolada configurada.
function gpsPrepararBaseLaboratorio_() {
  const id = PropertiesService.getScriptProperties().getProperty('GPS_LAB_DB_ID');
  if (!id) throw new Error('Configure GPS_LAB_DB_ID para uma planilha experimental.');
  const trava = LockService.getScriptLock();
  trava.waitLock(10000);
  try {
    gpsCriarEstrutura_(SpreadsheetApp.openById(id));
    SpreadsheetApp.flush();
  } finally {
    trava.releaseLock();
  }
}

function gpsCriarEstrutura_(planilha) {
  for (const [nome, campos] of Object.entries(GPS_SCHEMA)) {
    const aba = planilha.getSheetByName(nome);
    if (!aba || !aba.getLastRow()) continue;
    const esperados = ['id', ...campos];
    const atuais = aba.getRange(1, 1, 1, esperados.length).getValues()[0];
    if (aba.getLastColumn() > esperados.length ||
        atuais.some((campo, i) => i < aba.getLastColumn() && campo !== esperados[i])) {
      throw new Error('Cabeçalho incompatível: ' + nome);
    }
  }
  for (const [nome, campos] of Object.entries(GPS_SCHEMA)) {
    const aba = planilha.getSheetByName(nome) || planilha.insertSheet(nome);
    const existentes = aba.getLastRow() ? aba.getLastColumn() : 0;
    const cabecalho = ['id', ...campos];
    if (existentes < cabecalho.length) {
      const adicionais = cabecalho.slice(existentes);
      aba.getRange(1, existentes + 1, 1, adicionais.length).setValues([adicionais]);
    }
    aba.setFrozenRows(1);
  }
}
// Execute uma vez no editor do projeto isolado. Os IDs ficam em propriedades privadas.
function gpsInstalarDemonstracao_() {
  gpsComTrava_(() => {
    const props = PropertiesService.getScriptProperties();
    const modo = props.getProperty('GPS_LAB_MODO');
    if (modo !== 'demonstracao' && (props.getProperty('GPS_LAB_DB_ID') || props.getProperty('GPS_LAB_FOLDER_ID'))) {
      throw new Error('Use um projeto novo e isolado para instalar a demonstração.');
    }
    props.setProperties({ GPS_LAB_MODO: 'demonstracao', GPS_LAB_AUTOMACAO: 'false', GPS_LAB_EMAIL: 'false' });
    let data = props.getProperty('GPS_LAB_DEMO_DATA');
    if (!data) {
      data = gpsHoje_();
      props.setProperty('GPS_LAB_DEMO_DATA', data);
    }
    if (!props.getProperty('GPS_LAB_DB_ID')) {
      props.setProperty('GPS_LAB_DB_ID', SpreadsheetApp.create('GPS 2.0 · Base sintética').getId());
    }
    if (!props.getProperty('GPS_LAB_FOLDER_ID')) {
      props.setProperty('GPS_LAB_FOLDER_ID', DriveApp.createFolder('GPS 2.0 · Pasta sintética').getId());
    }
    const base = gpsAbrirBase_();
    gpsCriarEstrutura_(base);
    for (const [tabela, linhas] of Object.entries(gpsDadosDemonstracao_(data))) {
      const existentes = new Set(gpsTabela_(base, tabela).registros.map(r => r.id));
      gpsAnexar_(base, tabela, linhas.filter(r => !existentes.has(r.id)));
    }
    props.setProperty('GPS_LAB_CRITERIO_VERSAO', 'demo-v1');
  });
}

function gpsDadosDemonstracao_(data) {
  if (!gpsDataValida_(data)) throw new Error('Data de demonstração inválida');
  const ano = Number(data.slice(0, 4));
  const anoId = 'DEMO-ANO';
  const pasta = 'DEMO-PASTA';
  const componente = 'DEMO-LP';
  const anterior = deslocamento => {
    const dia = new Date(data + 'T00:00:00Z');
    dia.setUTCDate(dia.getUTCDate() + deslocamento);
    return dia.toISOString().slice(0, 10);
  };
  const municipios = Array.from({ length: 4 }, (_, i) => ({
    id: 'DEMO-M' + (i + 1), nome: 'Município fictício ' + (i + 1)
  }));
  const escolas = Array.from({ length: 40 }, (_, i) => ({
    id: 'DEMO-E' + (i + 1), codigo: 'DEMO-' + (i + 1), nome: 'Escola fictícia ' + (i + 1),
    municipio_id: municipios[i % 4].id,
    latitude: -10 - Math.floor(i / 8) * 0.08 - (i % 3) * 0.014,
    longitude: -39 + (i % 8) * 0.1
  }));
  const pecs = [{ id: 'DEMO-PEC', nome: 'PEC de demonstração' }, { id: 'DEMO-PEC2', nome: 'Outro PEC fictício' }];
  const atribuicoes = escolas.map((escola, i) => ({
    id: 'DEMO-A' + (i + 1), pec_id: pecs[i % 2].id, pasta_id: pasta,
    escola_id: escola.id, ano_letivo_id: anoId
  }));
  const turmas = escolas.map((escola, i) => ({
    id: 'DEMO-T' + (i + 1), escola_id: escola.id, ano_letivo_id: anoId, codigo: '8A', serie: 'EF8'
  }));
  const visitas = escolas.slice(0, 12).map((escola, i) => ({
    id: 'DEMO-V' + (i + 1), escola_id: escola.id, pec_id: pecs[i % 2].id,
    pasta_id: pasta, componente_id: componente, turma_id: turmas[i].id,
    data: anterior((i - 6) * 3), status: 'agendada'
  }));
  const escalaAtual = 'demo-pp';
  const escalaHistorica = 'saresp:nota:' + (ano - 1);
  const avaliacoes = escolas.slice(0, 12).flatMap((escola, i) => [{
    id: 'DEMO-IH' + i, escola_id: escola.id, componente_id: componente, ano: ano - 1,
    serie: 'EF7', fonte: 'saresp', metrica: 'nota', escala: escalaHistorica, valor: 2 + i % 6, revisar: false
  }, {
    id: 'DEMO-IA' + i, escola_id: escola.id, turma_id: turmas[i].id, componente_id: componente, ano,
    serie: 'EF8', fonte: 'prova_paulista', metrica: 'acerto', escala: escalaAtual, valor: 45 + i * 3, revisar: false
  }]);
  return {
    municipios, escolas, pecs, pastas: [{ id: pasta, nome: 'Qualidade da Aula · demonstração' }],
    anos_letivos: [{ id: anoId, ano }], atribuicoes,
    escopos_at: escolas.slice(0, 8).map((escola, i) => ({ id: 'DEMO-AT-E' + i, usuario_id: 'DEMO-AT', escola_id: escola.id })),
    turmas, componentes: [{ id: componente, nome: 'Língua Portuguesa' }],
    visitas,
    apoios: visitas.slice(0, 4).map((r, i) => ({ ...r, id: 'DEMO-AP' + i })),
    termos_web: visitas.slice(0, 3).map((r, i) => ({
      id: 'DEMO-TERMO' + i, visita_id: r.id, pec_id: r.pec_id, tipo: 'termo_visita', observacao: 'Evidência fictícia.'
    })),
    indicadores: avaliacoes,
    criterios: [
      { id: 'DEMO-C1', fonte: 'saresp', metrica: 'nota', escala: escalaHistorica, direcao: 'abaixo', limite: 4, versao: 'demo-v1', aprovado_cec: true },
      { id: 'DEMO-C2', fonte: 'prova_paulista', metrica: 'acerto', escala: escalaAtual, direcao: 'abaixo', limite: 60, versao: 'demo-v1', aprovado_cec: true }
    ],
    metas: [{ id: 'DEMO-META', pasta_id: pasta, atividade: 'visita', periodicidade: 'quinzena', quantidade: 1, por_escola: true, obrigatoria: true }],
    alertas: [{ id: 'DEMO-ALERTA', tipo: 'termo_pendente', criticidade: 'media',
      destinatario_id: 'DEMO-PEC', periodo: data, status: 'aberto', envio: 'popup' }]
  };
}

function gpsModoDemonstracao_() {
  return PropertiesService.getScriptProperties().getProperty('GPS_LAB_MODO') === 'demonstracao';
}
function gpsNormalizar_(texto) {
  return String(texto ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function gpsClassificarDocumento_(texto) {
  const corpo = gpsNormalizar_(texto);
  const saeb = /\b(saeb|sistema de avaliacao da educacao basica)\b/.test(corpo);
  const saresp = /\b(saresp|sistema de avaliacao de rendimento escolar do estado de sao paulo)\b/.test(corpo);
  if (saeb || saresp) {
    const abertura = corpo.split('\n').slice(0, 5).join('\n');
    const temBoletim = /\b(boletim|resultado|proficiencia)\b/.test(abertura);
    return !temBoletim || saeb && saresp
      ? { tipo: 'avaliacao_indeterminada', revisar: true }
      : { tipo: saeb ? 'saeb' : 'saresp', revisar: false };
  }
  const titulo = corpo.split('\n').find(linha => linha.trim()) || '';
  const tipos = [
    [/ficha (oficial )?de visita/, 'ficha_visita'],
    [/termo (detalhado )?de visita/, 'termo_visita'],
    [/plano de trabalho/, 'plano'],
    [/avaliacao diagnostica/, 'avd'],
    [/prova paulista/, 'prova_paulista'],
    [/frequencia escolar/, 'frequencia']
  ].filter(([padrao]) => padrao.test(titulo));
  return tipos.length === 1 ? { tipo: tipos[0][1], revisar: false } : { tipo: 'indeterminado', revisar: true };
}

function gpsDetectarCabecalho_(linhas, aliases) {
  const localizados = [];
  linhas.forEach((linha, i) => {
    const campos = {};
    for (const [campo, nomes] of Object.entries(aliases)) {
      const correspondencias = linha.map(gpsNormalizar_)
        .flatMap((celula, coluna) => nomes.includes(celula) ? [coluna] : []);
      if (correspondencias.length === 1) campos[campo] = correspondencias[0];
    }
    if (Object.keys(campos).length === Object.keys(aliases).length &&
        new Set(Object.values(campos)).size === Object.keys(campos).length) {
      localizados.push({ linha: i, campos });
    }
  });
  return localizados;
}

function gpsLerCSV_(texto) {
  const corpo = String(texto).replace(/^\uFEFF/, '').trimStart();
  const alternativas = [',', ';', '\t'].map(separador => {
    const linhas = Utilities.parseCsv(corpo, separador);
    const tamanhos = linhas.filter(linha => linha.some(celula => celula.trim())).map(linha => linha.length);
    const largura = tamanhos[0] || 0;
    return { linhas, valido: largura > 1 && tamanhos.every(tamanho => tamanho === largura) };
  }).filter(item => item.valido);
  if (alternativas.length !== 1) throw new Error('Separador CSV ausente ou ambíguo');
  return alternativas[0].linhas;
}

function gpsValorAvaliacao_(original, unidade) {
  const texto = String(original ?? '').trim();
  if (['', '-', '—'].includes(texto)) return { original, valor: null, revisar: false };
  const numero = texto.replace(/\s*%$/, '');
  if (!/^[-+]?\d+(?:[.,]\d+)?$/.test(numero) ||
      (/[.,]\d{3}$/.test(numero) && !texto.endsWith('%') && unidade !== 'percentual') ||
      (texto.endsWith('%') && unidade !== 'percentual')) return { original, valor: null, revisar: true };
  const valor = Number(numero.replace(',', '.'));
  if (!Number.isFinite(valor)) return { original, valor: null, revisar: true };
  return { original, valor, revisar: unidade === 'percentual' && (valor < 0 || valor > 100) };
}

function gpsLerImagensSAEB_(imagens, obterTexto) {
  return Array.from(imagens, (imagem, indice) => {
    const ordem = indice + 1;
    try {
      const texto = String(obterTexto(imagem) ?? '').trim();
      return { ordem, texto, revisar: true, motivo: texto ? 'conferir_ordem_e_valores_ocr' : 'ocr_sem_texto' };
    } catch (erro) {
      const motivo = /imageId/i.test(String(erro.message)) ? 'image_id_invalido' : 'falha_ocr';
      return { ordem, texto: '', revisar: true, motivo };
    }
  });
}

function gpsImportarIndicadores_(linhas, contexto) {
  const { fonte, documento_id, escala, metrica, unidade } = contexto;
  if (!GPS_FONTES.includes(fonte) || !documento_id || !escala || !metrica) {
    throw new Error('Contexto da avaliação incompleto');
  }
  if (linhas.some(linha => linha.some(celula => /^(cpf|rg|ra|nome do aluno|nome do estudante|registro do aluno)$/.test(gpsNormalizar_(celula))))) {
    return { indicadores: [], revisoes: [{ motivo: 'dados_individuais_bloqueados' }] };
  }
  const aliases = {
    ano: ['ano', 'ano de aplicacao'], serie: ['serie', 'ano/série'].map(gpsNormalizar_),
    componente: ['componente', 'componente curricular'], escola: ['codigo escola', 'escola'],
    valor: ['valor', 'resultado', 'percentual', 'nota']
  };
  if (fonte === 'avd') aliases.nivel = ['nivel', 'nivel de proficiencia'];
  const indicadores = [];
  const revisoes = [];
  const encontrados = new Map(gpsDetectarCabecalho_(linhas, aliases).map(item => [item.linha, item.campos]));
  let colunas;
  linhas.forEach((linha, indice) => {
    if (encontrados.has(indice)) {
      colunas = { ...encontrados.get(indice), turma: linha.map(gpsNormalizar_).indexOf('turma') };
      return;
    }
    if (!linha.some(item => String(item ?? '').trim())) return;
    if (!colunas) return;
    const ler = nome => String(linha[colunas[nome]] ?? '').trim();
    const ano = Number(ler('ano'));
    const serie = ler('serie').toUpperCase();
    const escola_id = ler('escola');
    const componente_id = ler('componente');
    const turma_id = ler('turma') || null;
    const nivel = ler('nivel') || null;
    const resultado = gpsValorAvaliacao_(ler('valor'), unidade);
    if (!/^\d{4}$/.test(ler('ano')) || !GPS_SERIES.includes(serie) ||
        !escola_id || !componente_id || (turma_id && fonte !== 'prova_paulista') ||
        (fonte === 'saeb' && ano % 2 !== 1) || (fonte === 'avd' && !GPS_NIVEIS_AVD.includes(nivel))) {
      revisoes.push({ linha: indice + 1, motivo: 'estrutura_ou_escopo_invalido' });
      return;
    }
    const periodo = contexto.periodo ?? null;
    const id = gpsChave_(documento_id, fonte, ano, periodo, escola_id, turma_id, serie, componente_id, metrica, nivel);
    indicadores.push({
      id, ano, serie, escola_id, componente_id, turma_id, nivel, documento_id,
      fonte, escala, metrica, periodo, valor_original: resultado.original,
      valor: resultado.valor, revisar: resultado.revisar
    });
    if (resultado.revisar) revisoes.push({ linha: indice + 1, motivo: 'valor_requer_revisao' });
  });
  if (!encontrados.size) revisoes.push({ motivo: 'cabecalho_indeterminado' });
  const contagem = new Map();
  for (const item of indicadores) contagem.set(item.id, (contagem.get(item.id) || 0) + 1);
  const idsDuplicados = [...contagem].filter(([, quantidade]) => quantidade > 1).map(([id]) => id);
  for (const id of idsDuplicados) revisoes.push({ id, motivo: 'indicador_duplicado' });
  return { indicadores: indicadores.filter(item => contagem.get(item.id) === 1), revisoes };
}

function gpsLerGrade_(aba) {
  const intervalo = aba.getDataRange();
  const linhas = intervalo.getDisplayValues();
  for (const mescla of intervalo.getMergedRanges()) {
    const linha = mescla.getRow() - intervalo.getRow();
    const coluna = mescla.getColumn() - intervalo.getColumn();
    for (let i = linha; i < Math.min(linhas.length, linha + mescla.getNumRows()); i++) {
      for (let j = coluna; j < Math.min(linhas[i].length, coluna + mescla.getNumColumns()); j++) {
        linhas[i][j] = linhas[linha][coluna];
      }
    }
  }
  return linhas;
}

// A origem deve pertencer ao laboratório. O serviço avançado usa o projeto padrão do Apps Script.
function gpsOCRBlob_(blob, pastaId) {
  const temporario = Drive.Files.create(
    { name: 'GPS LAB OCR temporário', mimeType: 'application/vnd.google-apps.document', parents: [pastaId], appProperties: { gpsTemporario: 'true' } },
    blob, { fields: 'id', ocrLanguage: 'pt' }
  );
  try {
    return DocumentApp.openById(temporario.id).getBody().getText();
  } finally {
    DriveApp.getFileById(temporario.id).setTrashed(true);
  }
}

function gpsLerArquivoLaboratorio_(arquivoId) {
  const pastaId = PropertiesService.getScriptProperties().getProperty('GPS_LAB_FOLDER_ID');
  if (!pastaId) throw new Error('Configure a pasta privada de laboratório');
  const arquivo = DriveApp.getFileById(arquivoId);
  const pais = arquivo.getParents();
  let autorizado = false;
  while (pais.hasNext()) if (pais.next().getId() === pastaId) autorizado = true;
  if (!autorizado) throw new Error('Arquivo fora da pasta direta de laboratório');
  const mime = arquivo.getMimeType();
  const sheets = 'application/vnd.google-apps.spreadsheet';
  const docs = 'application/vnd.google-apps.document';
  if (mime === 'text/csv') return { grades: [gpsLerCSV_(arquivo.getBlob().getDataAsString('UTF-8'))] };
  if (mime === sheets) return { grades: SpreadsheetApp.openById(arquivoId).getSheets().map(gpsLerGrade_) };
  const destino = ({
    'application/pdf': docs, 'application/msword': docs,
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': docs,
    'application/vnd.ms-excel': sheets,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': sheets
  })[mime];
  if (!destino) throw new Error('Formato documental não suportado');
  const temporario = Drive.Files.create(
    { name: 'GPS LAB temporário', mimeType: destino, parents: [pastaId], appProperties: { gpsTemporario: 'true' } }, arquivo.getBlob(),
    { fields: 'id', ...(destino === docs ? { ocrLanguage: 'pt' } : {}) }
  );
  try {
    if (destino === sheets) return { grades: SpreadsheetApp.openById(temporario.id).getSheets().map(gpsLerGrade_) };
    const corpo = DocumentApp.openById(temporario.id).getBody();
    const texto = corpo.getText();
    const classificacao = gpsClassificarDocumento_(texto);
    const grades = corpo.getTables().map(tabela => Array.from(
      { length: tabela.getNumRows() }, (_, i) => {
        const linha = tabela.getRow(i);
        return Array.from({ length: linha.getNumCells() }, (_, j) => linha.getCell(j).getText());
      }
    ));
    let imagens = [];
    if (mime === 'application/pdf' && classificacao.tipo !== 'saresp') {
      try {
        imagens = gpsLerImagensSAEB_(corpo.getImages(), imagem => gpsOCRBlob_(imagem.getBlob(), pastaId));
      } catch (erro) {
        imagens.push({ ordem: null, texto: '', revisar: true,
          motivo: /imageId/i.test(String(erro.message)) ? 'image_id_invalido' : 'imagens_indisponiveis' });
      }
    }
    if (classificacao.tipo === 'saeb' && typeof Drive.Files.export === 'function') {
      imagens = gpsRecuperarImagensExportadas_(temporario.id, imagens, pastaId);
    }
    return { texto, classificacao, grades, requerRevisao: mime === 'application/pdf' || classificacao.revisar, imagens };
  } finally {
    DriveApp.getFileById(temporario.id).setTrashed(true);
  }
}
function gpsAtualizarFila_(fila, entradas) {
  const itens = new Map(fila.map(item => [item.id, item]));
  for (const entrada of entradas) {
    if (!entrada.origem || !entrada.chave || !entrada.versao) throw new Error('Origem documental incompleta');
    const id = gpsChave_(entrada.chave, entrada.versao);
    if (!itens.has(id)) itens.set(id, { id, origem: entrada.origem, status: 'pendente', tentativas: 0 });
  }
  return [...itens.values()];
}

function gpsProcessarLote_(fila, limite, processar, maxTentativas = 3) {
  if (!Number.isInteger(limite) || limite < 1 || !Number.isInteger(maxTentativas) || maxTentativas < 1) {
    throw new Error('Limites de processamento inválidos');
  }
  let processados = 0;
  return fila.map(item => {
    if (processados >= limite || !['pendente', 'repetir'].includes(item.status)) return item;
    processados++;
    const tentativas = item.tentativas + 1;
    try {
      const resultado = processar(item.origem);
      return { ...item, tentativas, status: resultado.revisar ? 'revisao' : 'concluido' };
    } catch {
      return { ...item, tentativas, status: tentativas >= maxTentativas ? 'erro' : 'repetir' };
    }
  });
}

function gpsCaminhoTermo_(dataVisita, pecId, escolaId) {
  const segmento = valor => typeof valor === 'string' && /^[\p{L}\p{N}_-]+$/u.test(valor);
  if (!gpsDataValida_(dataVisita) || !segmento(pecId) || !segmento(escolaId)) {
    throw new Error('Destino documental inválido');
  }
  return ['Termos de Visita', dataVisita.slice(0, 4), dataVisita.slice(5, 7), pecId, escolaId];
}

function gpsConciliarAlertas_(historico, sinais, hoje, intervaloDias = 7) {
  if (!gpsDataValida_(hoje) || !Number.isInteger(intervaloDias) || intervaloDias < 1) {
    throw new Error('Configuração de recorrência inválida');
  }
  const estado = new Map(historico.map(item => [item.id, item]));
  const notificacoes = [];
  for (const sinal of sinais) {
    if (!sinal.tipo || !sinal.alvo_id || !sinal.periodo || !sinal.destinatario_id) continue;
    const id = gpsChave_(sinal.tipo, sinal.alvo_id, sinal.periodo, sinal.destinatario_id);
    const anterior = estado.get(id);
    if (anterior?.status === 'resolvido' || anterior?.status === 'justificado') continue;
    const dias = anterior?.ultima_notificacao
      ? (Date.parse(hoje) - Date.parse(anterior.ultima_notificacao)) / 86400000 : Infinity;
    if (dias < intervaloDias) continue;
    const alerta = {
      ...anterior, id, tipo: sinal.tipo, alvo_id: sinal.alvo_id, periodo: sinal.periodo,
      destinatario_id: sinal.destinatario_id, criticidade: sinal.criticidade || 'media',
      status: 'aberto', ultima_notificacao: hoje,
      ocorrencias: (anterior?.ocorrencias || 0) + 1
    };
    estado.set(id, alerta);
    notificacoes.push(alerta);
  }
  return { alertas: [...estado.values()], notificacoes };
}
function gpsSinaisAtuacao_(base, hoje) {
  const ano = Number(hoje.slice(0, 4));
  const atividades = gpsAtividadesBase_(base, hoje);
  const prioridades = gpsPrioridadesBase_(base, ano);
  const porId = new Map(prioridades.map(r => [r.id, r]));
  const anoId = gpsTabela_(base, 'anos_letivos').registros.find(r => Number(r.ano) === ano)?.id;
  const atribuicoes = gpsTabela_(base, 'atribuicoes').registros.filter(r => r.ano_letivo_id === anoId);
  const sinais = [];
  function sinal(tipo, alvo_id, periodo, destinatario_id, criticidade = 'media') {
    sinais.push({ tipo, alvo_id, periodo, destinatario_id, criticidade });
  }
  for (const resultado of gpsMonitorarPrioridades_(prioridades, atividades)) {
    if (resultado.direcionamento === 'alinhado' && resultado.evidencias !== 'sem_evidencia_documental') continue;
    const prioridade = porId.get(resultado.prioridade_id);
    const responsaveis = atribuicoes.filter(item => item.escola_id === prioridade.escola_id);
    for (const pec of responsaveis.length ? responsaveis.map(r => r.pec_id) : ['cec']) {
      sinal(resultado.evidencias === 'sem_evidencia_documental' ? 'prioridade_sem_evidencia' : 'prioridade_nao_contemplada',
        prioridade.id, String(ano), pec, 'alta');
    }
  }
  for (const r of atividades) {
    if (r.aguardandoTermo && Date.parse(hoje) - Date.parse(r.data) >= 7 * 86400000) {
      sinal('termo_pendente', r.id, r.data, r.pec_id);
    }
  }
  const alertas = new Map(gpsTabela_(base, 'alertas').registros.map(r => [r.id, r]));
  for (const r of gpsTabela_(base, 'encaminhamentos').registros) {
    const alerta = alertas.get(r.alerta_id);
    if (!alerta || !gpsDataValida_(r.prazo) || ['resolvido', 'concluido'].includes(r.status)) continue;
    const dias = (Date.parse(r.prazo) - Date.parse(hoje)) / 86400000;
    if (dias <= 3) sinal(dias < 0 ? 'encaminhamento_nao_retomado' : 'prazo_proximo', r.id, r.prazo, alerta.destinatario_id);
  }
  const metas = gpsTabela_(base, 'metas').registros.filter(r => r.obrigatoria === true);
  for (const meta of metas) {
    const periodo = gpsPeriodoFechado_(hoje, meta.periodicidade);
    if (!periodo) continue;
    const atribuicoesMeta = atribuicoes.filter(r => r.pasta_id === meta.pasta_id);
    for (const r of atribuicoesMeta) {
      const relevantes = atividades.filter(a => a.pasta_id === r.pasta_id);
      const escola = meta.por_escola ? r.escola_id : '';
      if (gpsAvaliarMeta_(meta, relevantes, r.pec_id, periodo, escola).pendente) {
        sinal('meta_nao_atingida', gpsChave_(meta.id, escola), periodo.fim, r.pec_id);
      }
    }
  }
  return sinais;
}

function gpsPeriodoFechado_(hoje, tipo) {
  const data = new Date(hoje + 'T00:00:00Z');
  const iso = d => d.toISOString().slice(0, 10);
  const inicio = new Date(data);
  const fim = new Date(data);
  if (tipo === 'semana') {
    inicio.setUTCDate(data.getUTCDate() - ((data.getUTCDay() + 6) % 7) - 7);
    fim.setTime(inicio.getTime() + 6 * 86400000);
  } else if (tipo === 'quinzena') {
    if (data.getUTCDate() > 15) {
      inicio.setUTCDate(1);
      fim.setUTCDate(15);
    } else {
      inicio.setUTCMonth(data.getUTCMonth() - 1, 16);
      fim.setUTCDate(0);
    }
  } else return null;
  return { inicio: iso(inicio), fim: iso(fim), hoje };
}

function gpsExecutarAlertas_(base, hoje, enviar) {
  const usuarios = gpsTabela_(base, 'usuarios').registros.filter(r => r.ativo === true);
  const sinaisPec = gpsSinaisAtuacao_(base, hoje);
  const cecs = usuarios.filter(r => r.perfil === 'CEC');
  const sinais = sinaisPec.filter(s => s.destinatario_id !== 'cec').concat(cecs.flatMap(u => sinaisPec.map(s => ({
    ...s, alvo_id: gpsChave_(s.alvo_id, s.destinatario_id), destinatario_id: 'cec:' + u.id
  }))));
  const anteriores = gpsTabela_(base, 'alertas').registros;
  const porId = new Map(anteriores.map(item => [item.id, item]));
  const resultado = gpsConciliarAlertas_(anteriores, sinais, hoje);
  for (const alerta of resultado.notificacoes) {
    const anterior = porId.get(alerta.id);
    const envio = anterior?.envio === 'reservado' ? 'reservado' : enviar ? 'pendente' : 'popup';
    gpsAtualizarEstado_(base, 'alertas', anterior, { ...alerta, envio });
    gpsAuditar_(base, 'alertas', alerta.id, 'notificacao:' + alerta.ocorrencias, 'automacao');
  }
  if (!enviar) return;
  const pendentes = gpsTabela_(base, 'alertas').registros.filter(r => r.envio === 'pendente' && r.status === 'aberto');
  for (const alerta of pendentes.slice(0, 10)) {
    const destinatarios = usuarios.filter(u => u.perfil === 'CEC' ? 'cec:' + u.id === alerta.destinatario_id :
      u.perfil === 'PEC' && u.pec_id === alerta.destinatario_id);
    if (destinatarios.length !== 1 || !destinatarios[0].email) continue;
    // O envio é externo. Uma interrupção após a reserva exige conferência do operador.
    gpsAtualizarEstado_(base, 'alertas', alerta, { ...alerta, envio: 'reservado' });
    SpreadsheetApp.flush();
    try {
      enviar(destinatarios[0].email, 'GPS Pedagógico · aviso', 'Há um aviso de acompanhamento disponível no painel do GPS.');
    } catch {
      continue;
    }
    gpsAtualizarEstado_(base, 'alertas', alerta, { ...alerta, envio: 'enviado' });
  }
}

function gpsMeusAlertas() {
  const { base, perfil } = gpsSessao_();
  if (perfil.papel === 'AT') return [];
  return gpsTabela_(base, 'alertas').registros.filter(r => r.status === 'aberto' &&
    r.destinatario_id === (perfil.papel === 'CEC' ? 'cec:' + perfil.id : perfil.pec_id))
    .slice(-30).map(({ id, tipo, criticidade, periodo }) => ({ id, tipo, criticidade, periodo }));
}

function gpsJustificarAlerta(dados) {
  return gpsComTrava_(() => {
    const { base, perfil } = gpsSessao_();
    if (perfil.papel === 'AT') throw new Error('Perfil de consulta');
    const alerta = gpsTabela_(base, 'alertas').registros.find(r => r.id === dados.id && r.destinatario_id ===
      (perfil.papel === 'CEC' ? 'cec:' + perfil.id : perfil.pec_id));
    if (!alerta || !['aberto', 'justificado'].includes(alerta.status)) throw new Error('Alerta indisponível');
    const motivo = gpsTextoWeb_(dados.motivo);
    const digest = Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, motivo));
    const id = gpsChave_(alerta.id, perfil.id, digest);
    gpsAnexar_(base, 'justificativas', [{ id, alerta_id: alerta.id, pec_id: perfil.pec_id, motivo, status: 'registrada' }]);
    gpsAtualizarEstado_(base, 'alertas', alerta, { ...alerta, status: 'justificado' });
    gpsAuditar_(base, 'justificativas', id, 'registro_web', perfil.id);
    return { id };
  });
}


function gpsResolverAlertaTermo_(base, visita) {
  const espelhoCEC = gpsChave_(visita.id, visita.pec_id);
  const alertas = gpsTabela_(base, 'alertas').registros.filter(r => r.tipo === 'termo_pendente' &&
    (r.alvo_id === visita.id || r.alvo_id === espelhoCEC) && r.status !== 'resolvido');
  for (const alerta of alertas) {
    gpsAuditar_(base, 'alertas', alerta.id, 'termo_encerrado', visita.pec_id);
    gpsAtualizarEstado_(base, 'alertas', alerta, { ...alerta, status: 'resolvido' });
  }
}
function gpsAtividadesBase_(base, hoje) {
  const atividades = [['visitas', 'visita'], ['apoios', 'apoio']].flatMap(([aba, tipo]) =>
    gpsTabela_(base, aba).registros.filter(r => gpsDataValida_(r.data)).map(r => ({ ...r, tipo })));
  const evidencias = gpsTabela_(base, 'comprovantes').registros.concat(
    gpsTabela_(base, 'termos_web').registros.map(r => ({ ...r, validado: true })));
  const decisoes = gpsTabela_(base, 'decisoes_visita').registros;
  return gpsCruzarVisitas_(gpsAplicarDecisoesVisita_(atividades, decisoes), evidencias, hoje);
}

function gpsPrioridadesBase_(base, ano) {
  const versao = PropertiesService.getScriptProperties().getProperty('GPS_LAB_CRITERIO_VERSAO');
  const regras = gpsTabela_(base, 'criterios').registros.filter(r => r.versao === versao && r.aprovado_cec === true);
  if (!versao || !regras.length) return [];
  return gpsSelecionarPrioridades_(gpsTabela_(base, 'indicadores').registros, { versao, regras, aprovadaCEC: true }, ano);
}

function gpsAvisosFormulario(dados) {
  const { base, perfil } = gpsSessao_();
  const plano = gpsValidarAtividadeWeb_(base, perfil, dados);
  const prioridades = gpsPrioridadesBase_(base, Number(plano.data.slice(0, 4)))
    .filter(r => r.escola_id === plano.escola_id);
  const alinhadas = prioridades.filter(r => r.componente_id === plano.componente_id && (!r.turma_id || r.turma_id === plano.turma_id));
  return { prioridades: prioridades.length, alinhadas: alinhadas.length };
}

function gpsValidarAtividadeWeb_(base, perfil, dados) {
  const { escola_id, componente_id, turma_id, pasta_id, data, tipo } = dados || {};
  if (perfil.papel === 'AT' || !perfil.pec_id || !gpsDataValida_(data) || !['visita', 'apoio'].includes(tipo) ||
      !escola_id || !componente_id || !pasta_id) throw new Error('Preencha os campos obrigatórios');
  const ano = gpsTabela_(base, 'anos_letivos').registros.find(r => Number(r.ano) === Number(data.slice(0, 4)));
  const atribuida = ano && gpsTabela_(base, 'atribuicoes').registros.some(r =>
    r.pec_id === perfil.pec_id && r.escola_id === escola_id && r.pasta_id === pasta_id && r.ano_letivo_id === ano.id);
  if (!atribuida) throw new Error('Atividade fora da atribuição');
  if (!gpsTabela_(base, 'componentes').registros.some(r => r.id === componente_id)) throw new Error('Componente inválido');
  if (turma_id && !gpsTabela_(base, 'turmas').registros.some(r =>
    r.id === turma_id && r.escola_id === escola_id && r.ano_letivo_id === ano.id)) throw new Error('Turma fora da escola ou do ano');
  return { escola_id, componente_id, turma_id, pasta_id, data, tipo, pec_id: perfil.pec_id };
}

function gpsTextoWeb_(valor) {
  const texto = typeof valor === 'string' ? valor.trim() : '';
  if (!texto || texto.length > 1000) throw new Error('Informe um texto de até mil caracteres');
  return texto;
}

function gpsSalvarPlano(dados) {
  return gpsComTrava_(() => {
    const { base, perfil } = gpsSessao_();
    const r = gpsValidarAtividadeWeb_(base, perfil, dados);
    const horario = dados.horario || '';
    if (horario && !/^([01]\d|2[0-3]):[0-5]\d$/.test(horario)) throw new Error('Horário inválido');
    const id = gpsChave_(r.tipo, r.pec_id, r.data, r.escola_id, horario);
    const plano_id = gpsChave_('plano_web', id);
    const tabela = r.tipo === 'visita' ? 'visitas' : 'apoios';
    const atividade = { ...r, id, plano_id, horario, status: 'agendada' };
    gpsAnexar_(base, 'planos', [{ id: plano_id, pec_id: r.pec_id, periodo: r.data.slice(0, 7), objetivo: gpsTextoWeb_(dados.objetivo) }]);
    gpsAnexar_(base, tabela, [atividade]);
    gpsAuditar_(base, tabela, id, 'registro_web', perfil.id);
    return { id };
  });
}

function gpsContextoTermo(id) {
  const { base, perfil } = gpsSessao_();
  if (perfil.papel === 'AT') throw new Error('Perfil de consulta');
  const visita = gpsTabela_(base, 'visitas').registros.find(r => r.id === id && r.pec_id === perfil.pec_id);
  if (!visita) throw new Error('Visita indisponível');
  const avisos = gpsPrioridadesBase_(base, Number(visita.data.slice(0, 4))).filter(r =>
    r.escola_id === visita.escola_id && (r.componente_id !== visita.componente_id ||
      (r.turma_id && r.turma_id !== visita.turma_id)));
  return { divergencias: avisos.length };
}

function gpsSalvarTermo(dados) {
  return gpsComTrava_(() => {
    const { base, perfil } = gpsSessao_();
    if (perfil.papel === 'AT') throw new Error('Perfil de consulta');
    const visita = gpsTabela_(base, 'visitas').registros.find(r => r.id === dados.visita_id && r.pec_id === perfil.pec_id);
    const confirmadaNaoRealizada = gpsTabela_(base, 'decisoes_visita').registros.some(r =>
      r.visita_id === dados.visita_id && r.decisao === 'nao_ocorreu');
    if (!visita || visita.data > gpsHoje_() || visita.status === 'cancelada' || confirmadaNaoRealizada) throw new Error('Visita indisponível');
    if (!['termo_visita', 'ficha_visita'].includes(dados.tipo)) throw new Error('Tipo de evidência inválido');
    const id = gpsChave_('termo_web', visita.id, dados.tipo);
    gpsAnexar_(base, 'termos_web', [{ id, visita_id: visita.id, pec_id: perfil.pec_id,
      tipo: dados.tipo, observacao: gpsTextoWeb_(dados.observacao) }]);
    gpsAuditar_(base, 'termos_web', id, 'registro_web', perfil.id);
    if (dados.tipo === 'termo_visita') gpsResolverAlertaTermo_(base, visita);
    return { id };
  });
}

function gpsMinhasOpcoes() {
  const { base, perfil } = gpsSessao_();
  if (perfil.papel === 'AT') return { papel: 'AT', escolas: [], pastas: [], componentes: [], turmas: [], visitas: [] };
  const atribuicoes = gpsTabela_(base, 'atribuicoes').registros.filter(r => r.pec_id === perfil.pec_id);
  const opcoes = (tabela, ids) => gpsTabela_(base, tabela).registros.filter(r => !ids || ids.has(r.id))
    .map(r => ({ id: r.id, nome: r.nome || r.codigo || r.id }));
  const escolas = new Set(atribuicoes.map(r => r.escola_id));
  const escolasOpcoes = opcoes('escolas', escolas);
  const nomesEscolas = new Map(escolasOpcoes.map(r => [r.id, r.nome]));
  return {
    papel: perfil.papel, escolas: escolasOpcoes,
    pastas: opcoes('pastas', new Set(atribuicoes.map(r => r.pasta_id))),
    componentes: opcoes('componentes'),
    turmas: gpsTabela_(base, 'turmas').registros.filter(r => escolas.has(r.escola_id))
      .map(r => ({ id: r.id, nome: r.codigo || r.id, escola_id: r.escola_id })),
    visitas: gpsTabela_(base, 'visitas').registros.filter(r => r.pec_id === perfil.pec_id &&
      r.status !== 'cancelada' && r.data <= gpsHoje_()).slice(-100)
      .map(r => ({ id: r.id, nome: r.data + ' · ' + (nomesEscolas.get(r.escola_id) || 'Escola sem cadastro na atribuição') }))
  };
}

function gpsRevisarIndicador(dados) {
  return gpsComTrava_(() => {
    const { base, perfil } = gpsSessao_();
    if (perfil.papel !== 'CEC') throw new Error('Acesso restrito ao CEC');
    const item = gpsTabela_(base, 'indicadores').registros.find(r => r.id === dados.id);
    if (!item || item.revisar !== true) throw new Error('Indicador indisponível para revisão');
    const valor = dados.valor;
    if (valor !== null && (typeof valor !== 'number' || !Number.isFinite(valor))) throw new Error('Valor inválido');
    gpsAuditar_(base, 'indicadores', item.id, 'validado:' + gpsChave_(valor), perfil.id);
    gpsAtualizarEstado_(base, 'indicadores', item, { ...item, valor, revisar: false });
    return { id: item.id };
  });
}


function gpsAplicarDecisoesVisita_(atividades, decisoes) {
  const porVisita = new Map(decisoes.map(r => [r.visita_id, r.decisao]));
  return atividades.map(r => {
    if (r.tipo !== 'visita') return r;
    const decisao = porVisita.get(r.id);
    return decisao === 'nao_ocorreu' ? { ...r, status: 'cancelada', decisao } : decisao ? { ...r, decisao } : r;
  });
}

function gpsRegistrarDecisaoVisita(dados) {
  return gpsComTrava_(() => {
    const { base, perfil } = gpsSessao_();
    if (perfil.papel !== 'PEC' || !['termo_atrasado', 'nao_ocorreu'].includes(dados?.decisao)) {
      throw new Error('Decisão de visita indisponível');
    }
    const hoje = gpsHoje_();
    const visita = gpsAtividadesBase_(base, hoje).find(r => r.tipo === 'visita' &&
      r.id === dados.visita_id && r.pec_id === perfil.pec_id);
    if (!visita) throw new Error('Visita indisponível para esta decisão.');
    const id = gpsChave_('decisao_visita', visita.id, dados.decisao);
    const existente = gpsTabela_(base, 'decisoes_visita').registros.find(r => r.id === id);
    if (existente) {
      gpsAuditar_(base, 'decisoes_visita', id, dados.decisao, perfil.id);
      if (dados.decisao === 'nao_ocorreu') gpsResolverAlertaTermo_(base, visita);
      return { id };
    }
    if (!visita.aguardandoTermo || (Date.parse(hoje) - Date.parse(visita.data)) < 7 * 86400000 ||
        (dados.decisao === 'nao_ocorreu' && visita.comprovada)) {
      throw new Error('Visita indisponível para esta decisão. Confirme a data e as evidências.');
    }
    const motivo = dados.decisao === 'nao_ocorreu' ? gpsTextoWeb_(dados.motivo) : '';
    gpsAnexar_(base, 'decisoes_visita', [{ id, visita_id: visita.id, pec_id: perfil.pec_id,
      decisao: dados.decisao, motivo, instante: new Date().toISOString() }]);
    gpsAuditar_(base, 'decisoes_visita', id, dados.decisao, perfil.id);
    if (dados.decisao === 'nao_ocorreu') gpsResolverAlertaTermo_(base, visita);
    return { id };
  });
}
const GPS_SERIES = Array.from({length: 9}, (_, i) => 'EF' + (i + 1)).concat('EM1', 'EM2', 'EM3');
const GPS_NIVEIS_AVD = ['Abaixo do Básico', 'Básico', 'Proficiente'];
const GPS_FONTES = ['saresp', 'saeb', 'prova_paulista', 'avd', 'frequencia'];

function gpsProjetarCoorte_(indicador, ano) {
  const { fonte, ano: aplicacao, serie } = indicador;
  const posicao = GPS_SERIES.indexOf(serie);
  if (!['saresp', 'saeb'].includes(fonte) || !Number.isInteger(aplicacao) ||
      !Number.isInteger(ano) || ano < aplicacao || posicao < 0 ||
      (fonte === 'saeb' && aplicacao % 2 !== 1)) return null;
  const destino = GPS_SERIES[posicao + ano - aplicacao];
  return {
    anoAplicacao: aplicacao, serieAplicacao: serie, anoAcompanhamento: ano,
    serieAcompanhamento: destino || null,
    situacao: destino ? 'referencia_sem_vinculo_individual' : 'conclusao_prevista',
    escolaOrigem: indicador.escola_id || null
  };
}

function gpsSelecionarPrioridades_(indicadores, politica, ano) {
  if (!politica?.aprovadaCEC || !politica.versao) throw new Error('Critérios precisam de aprovação do CEC');
  const resultados = [];
  for (const indicador of indicadores) {
    if (!GPS_FONTES.includes(indicador.fonte) ||
        !Number.isFinite(indicador.valor) || indicador.revisar ||
        (indicador.turma_id && indicador.fonte !== 'prova_paulista') ||
        (indicador.fonte === 'avd' && indicador.nivel && !GPS_NIVEIS_AVD.includes(indicador.nivel))) continue;
    const regra = politica.regras.find(item => item.fonte === indicador.fonte &&
      item.escala === indicador.escala && item.metrica === indicador.metrica &&
      (item.nivel ?? '') === (indicador.nivel ?? ''));
    if (!regra || !Number.isFinite(regra.limite) || !['abaixo', 'acima'].includes(regra.direcao)) continue;
    const fragilidade = regra.direcao === 'abaixo' ? indicador.valor < regra.limite : indicador.valor > regra.limite;
    const historico = indicador.ano !== ano;
    const coorte = historico ? gpsProjetarCoorte_(indicador, ano) : null;
    if (historico && !coorte?.serieAcompanhamento) continue;
    resultados.push({ indicador, coorte, fragilidade });
  }
  const referencias = new Map();
  const locais = new Map();
  for (const item of resultados) {
    const { indicador, coorte, fragilidade } = item;
    if (!coorte || !indicador.componente_id) continue;
    const regional = gpsChave_(coorte.serieAcompanhamento, indicador.componente_id);
    const local = gpsChave_(regional, indicador.escola_id);
    if (fragilidade) {
      if (!referencias.has(regional)) referencias.set(regional, []);
      referencias.get(regional).push(indicador.id);
    }
    if (indicador.escola_id) {
      if (!locais.has(local)) locais.set(local, []);
      locais.get(local).push(item);
    }
  }
  const prioridades = resultados.filter(item => !item.coorte && item.fragilidade).map(({ indicador }) => {
    const regional = gpsChave_(indicador.serie, indicador.componente_id);
    const referenciasLocais = locais.get(gpsChave_(regional, indicador.escola_id)) || [];
    const fragilidadesLocais = referenciasLocais.filter(item => item.fragilidade);
    return {
      id: gpsChave_(politica.versao, indicador.id, ano),
      escola_id: indicador.escola_id, turma_id: indicador.turma_id,
      componente_id: indicador.componente_id, serie: indicador.serie, ano,
      fonte: indicador.fonte, indicador_id: indicador.id, criterio_versao: politica.versao,
      referencias_historicas: indicador.fonte === 'prova_paulista' ? referencias.get(regional) || [] : [],
      referencias_escola: referenciasLocais.map(item => item.indicador.id),
      diagnostico: fragilidadesLocais.length ? 'persistente' :
        referenciasLocais.length ? 'emergente' : 'sem_historico_escolar'
    };
  });
  return prioridades;
}
function gpsAbrirBase_() {
  const id = PropertiesService.getScriptProperties().getProperty('GPS_LAB_DB_ID');
  if (!id) throw new Error('Base de laboratório indisponível');
  return SpreadsheetApp.openById(id);
}

function gpsComTrava_(executar) {
  const trava = LockService.getScriptLock();
  trava.waitLock(10000);
  try {
    return executar();
  } finally {
    try { SpreadsheetApp.flush(); } finally { trava.releaseLock(); }
  }
}

function gpsTabela_(base, nome) {
  const aba = base.getSheetByName(nome);
  const campos = ['id', ...GPS_SCHEMA[nome]];
  const n = aba.getLastRow() - 1;
  const valores = n > 0 ? aba.getRange(2, 1, n, campos.length).getValues() : [];
  return {
    aba, campos,
    registros: valores.map((linha, i) => ({
      ...Object.fromEntries(campos.map((campo, j) => [campo, gpsLerCelula_(linha[j])])),
      _linha: i + 2
    })).filter(item => item.id)
  };
}

function gpsLerCelula_(valor) {
  if (valor instanceof Date) return Utilities.formatDate(valor, 'America/Sao_Paulo', 'yyyy-MM-dd');
  // Remove o escape apenas quando devolvido literalmente pelo adaptador.
  return typeof valor === 'string' && /^'[=+@-]/.test(valor) ? valor.slice(1) : valor;
}

function gpsCelula_(valor) {
  if (Array.isArray(valor)) return JSON.stringify(valor);
  return typeof valor === 'string' && /^[=+@-]/.test(valor) ? "'" + valor : valor ?? '';
}

function gpsAnexar_(base, nome, registros) {
  if (!registros.length) return;
  const destino = gpsTabela_(base, nome);
  const indice = { [nome]: new Map(destino.registros.map(item => [item.id, item])) };
  const refs = new Set(GPS_SCHEMA[nome].map(campo => GPS_RELACOES[campo]).filter(Boolean));
  for (const ref of refs) {
    if (!indice[ref]) indice[ref] = new Map(gpsTabela_(base, ref).registros.map(item => [item.id, item]));
  }
  const linhas = [];
  for (const registro of registros) {
    const normalizado = Object.fromEntries(destino.campos.map(campo => [
      campo, Array.isArray(registro[campo]) ? JSON.stringify(registro[campo]) : registro[campo]
    ]));
    if (!gpsValidarRegistro_(nome, normalizado, indice)) continue;
    indice[nome].set(registro.id, normalizado);
    linhas.push(destino.campos.map(campo => gpsCelula_(normalizado[campo])));
  }
  if (linhas.length) destino.aba.getRange(destino.aba.getLastRow() + 1, 1, linhas.length, destino.campos.length).setValues(linhas);
}

// Apenas para estado mutável de fila e notificações, sob a trava do script.
function gpsAtualizarEstado_(base, nome, anterior, registro) {
  const aba = base.getSheetByName(nome);
  const campos = ['id', ...GPS_SCHEMA[nome]];
  const linha = anterior?._linha || aba.getLastRow() + 1;
  aba.getRange(linha, 1, 1, campos.length).setValues([campos.map(campo => gpsCelula_(registro[campo]))]);
}

function gpsAuditar_(base, entidade, registro_id, operacao, ator_id) {
  const id = gpsChave_(entidade, registro_id, operacao);
  const aba = base.getSheetByName('auditoria');
  const ultima = aba.getLastRow();
  if (ultima >= 2 && aba.getRange(2, 1, ultima - 1, 1).createTextFinder(id).matchEntireCell(true).findNext()) return;
  gpsAnexar_(base, 'auditoria', [{ id, entidade, registro_id, operacao, ator_id, instante: new Date().toISOString() }]);
}
function gpsSituacaoDocumento_(obrigacao, hoje) {
  if (!gpsDataValida_(hoje)) throw new Error('Data de referência inválida');
  if (obrigacao.aplicavel === false) return { situacao: 'não aplicável', cor: 'cinza', lembrete: null };
  const prazo = obrigacao.prazo;
  if (!gpsDataValida_(prazo) || obrigacao.homologado !== true || !obrigacao.referencia) {
    return { situacao: 'prazo pendente de homologação', cor: 'cinza', lembrete: null };
  }
  const entrega = obrigacao.entrega;
  if (entrega && (!gpsDataValida_(entrega) || entrega > hoje)) {
    return { situacao: 'entrega em revisão', cor: 'cinza', lembrete: null };
  }
  if (entrega) return entrega > prazo
    ? { situacao: 'entregue com atraso', cor: 'amarelo', lembrete: null }
    : { situacao: 'entregue no prazo', cor: 'verde', lembrete: null };
  const dias = (Date.parse(prazo) - Date.parse(hoje)) / 86400000;
  if (dias < 0) return { situacao: 'vencido e pendente', cor: 'vermelho', lembrete: 'apos_prazo' };
  return { situacao: 'a vencer', cor: 'azul', lembrete: dias === 7 ? 'D-7' : dias === 2 ? 'D-2' : null };
}

function gpsSegundoDiaUtil_(mes, dias) {
  if (!/^\d{4}-\d{2}$/.test(mes) || !gpsDataValida_(mes + '-01')) throw new Error('Mês inválido');
  const porData = new Map();
  for (const item of dias.filter(r => String(r.data).slice(0, 7) === mes)) {
    if (porData.has(item.data)) return null;
    porData.set(item.data, item);
  }
  let encontrados = 0;
  for (let dia = 1; dia <= 31; dia++) {
    const data = mes + '-' + String(dia).padStart(2, '0');
    const item = porData.get(data);
    if (!gpsDataValida_(data) || item?.homologado !== true || !item.referencia || typeof item.util !== 'boolean') return null;
    if (item.util && ++encontrados === 2) return data;
  }
  return null;
}

function gpsAgregarFrequencia_(linhas) {
  let total = 0;
  let presencas = 0;
  let semCobertura = 0;
  for (const linha of linhas) {
    if (!Number.isSafeInteger(linha.denominador) || linha.denominador <= 0 ||
        !Number.isSafeInteger(linha.presencas) || linha.presencas < 0 || linha.presencas > linha.denominador) {
      semCobertura++;
      continue;
    }
    total += linha.denominador;
    presencas += linha.presencas;
  }
  return { percentual: total ? presencas * 100 / total : null, presencas, denominador: total, semCobertura };
}
const GPS_SINCRONIZACAO = 'GPS_LAB_CHECKPOINT_DRIVE';

function gpsDescobrirPagina_(pasta, estado, agora, listar) {
  if (!/^[\w-]+$/.test(pasta)) throw new Error('Pasta de laboratório inválida');
  const ate = estado.ate || agora;
  const q = ["'" + pasta + "' in parents", 'trashed = false', "modifiedTime < '" + ate + "'"];
  if (estado.desde) q.push("modifiedTime >= '" + estado.desde + "'");
  const pagina = listar({
    q: q.join(' and '), orderBy: 'modifiedTime', pageSize: 25, pageToken: estado.pagina || undefined,
    fields: 'nextPageToken,incompleteSearch,files(id,version,md5Checksum,mimeType,appProperties)'
  });
  if (pagina.incompleteSearch) throw new Error('Listagem incompleta');
  const entradas = (pagina.files || []).filter(item => item.version &&
    !item.appProperties?.gpsTemporario &&
    !['application/vnd.google-apps.folder', 'application/vnd.google-apps.shortcut'].includes(item.mimeType));
  return { entradas, proximo: pagina.nextPageToken
    ? { desde: estado.desde, ate, pagina: pagina.nextPageToken }
    : { desde: ate } };
}

function gpsImportarItemFila_(base, item) {
  const atual = Drive.Files.get(item.origem, { fields: 'version,md5Checksum' });
  const chave = atual.md5Checksum || item.origem;
  const idAtual = gpsChave_(chave, atual.md5Checksum ? 'conteudo' : String(atual.version));
  if (idAtual !== item.id) return 'substituido';
  const doc = gpsLerArquivoLaboratorio_(item.origem);
  const depois = Drive.Files.get(item.origem, { fields: 'version,md5Checksum' });
  if (String(atual.version) !== String(depois.version)) return 'substituido';
  const fonte = gpsTabela_(base, 'fontes_importacao').registros.filter(r => r.origem === item.origem);
  const contexto = fonte.length === 1 ? fonte[0] : null;
  const identificado = doc.classificacao?.tipo;
  const tipo = identificado || contexto?.fonte || 'indeterminado';
  let avaliacao = { indicadores: [], revisoes: [{ motivo: 'leiaute_pendente' }] };
  if (['saresp', 'saeb'].includes(identificado)) {
    avaliacao = gpsExtrairBoletim_(doc, identificado, item.id);
  } else if (contexto && !identificado) {
    const partes = (doc.grades || []).map(grade => gpsImportarIndicadores_(grade, { ...contexto, documento_id: item.id }));
    const indicadores = partes.flatMap(r => r.indicadores);
    const grupos = new Map();
    for (const r of indicadores) grupos.set(r.id, (grupos.get(r.id) || 0) + 1);
    const revisoes = partes.flatMap(r => r.revisoes);
    if ([...grupos.values()].some(total => total > 1)) revisoes.push({ motivo: 'indicador_duplicado_entre_abas' });
    avaliacao = { indicadores: indicadores.filter(r => grupos.get(r.id) === 1), revisoes };
  }
  gpsAnexar_(base, 'documentos', [{ id: item.id, chave, versao: item.versao, tipo, origem: item.origem }]);
  const escolas = gpsTabela_(base, 'escolas').registros;
  const componentes = gpsTabela_(base, 'componentes').registros;
  const turmas = gpsTabela_(base, 'turmas').registros;
  const anos = new Map(gpsTabela_(base, 'anos_letivos').registros.map(r => [r.id, Number(r.ano)]));
  const resolver = (registros, token, alias) => {
    const encontrados = registros.filter(r => String(r.id) === String(token) ||
      (r[alias] && gpsNormalizar_(r[alias]) === gpsNormalizar_(token)));
    return encontrados.length === 1 ? encontrados[0].id : null;
  };
  const validos = [];
  for (const r of avaliacao.indicadores) {
    const escola_id = resolver(escolas, r.escola_id, 'codigo');
    const componente_id = resolver(componentes, r.componente_id, 'nome');
    const turma_id = r.turma_id ? resolver(turmas.filter(t => t.escola_id === escola_id &&
      anos.get(t.ano_letivo_id) === r.ano && t.serie === r.serie), r.turma_id, 'codigo') : null;
    if (escola_id && componente_id && (!r.turma_id || turma_id)) validos.push({ ...r, escola_id, componente_id, turma_id });
  }
  if (validos.length !== avaliacao.indicadores.length) avaliacao.revisoes.push({ motivo: 'cadastro_nao_encontrado' });
  const requerRevisao = Boolean(doc.requerRevisao || avaliacao.revisoes.length);
  gpsAnexar_(base, 'indicadores', validos.map(r => ({ ...r, revisar: requerRevisao })));
  if (requerRevisao) {
    const motivos = [...new Set(avaliacao.revisoes.map(r => r.motivo).concat(doc.requerRevisao ? ['conferir_conversao'] : []))];
    gpsAnexar_(base, 'revisoes', motivos.map(motivo => ({
      id: gpsChave_(item.id, motivo), documento_id: item.id, motivo, status: 'aberta'
    })));
  }
  return requerRevisao ? 'revisao' : 'concluido';
}

function gpsSincronizarLaboratorio_() {
  const props = PropertiesService.getScriptProperties();
  const pasta = props.getProperty('GPS_LAB_FOLDER_ID');
  if (gpsModoDemonstracao_() || props.getProperty('GPS_LAB_AUTOMACAO') !== 'true' || !pasta) return;
  gpsComTrava_(() => {
    const base = gpsAbrirBase_();
    const chave = GPS_SINCRONIZACAO + '_' + pasta;
    const estado = JSON.parse(props.getProperty(chave) || '{}');
    let pagina;
    try {
      pagina = gpsDescobrirPagina_(pasta, estado, new Date().toISOString(), args => Drive.Files.list(args));
    } catch (erro) {
      // Retoma a janela com deduplicação quando um token de paginação expira.
      if (!estado.pagina || !/page.?token|invalid value/i.test(String(erro.message))) throw erro;
      props.setProperty(chave, JSON.stringify({ desde: estado.desde, ate: estado.ate }));
      return;
    }
    const entradas = pagina.entradas.map(r => {
      const versao = r.md5Checksum ? 'conteudo' : String(r.version);
      return { id: gpsChave_(r.md5Checksum || r.id, versao), origem: r.id, versao };
    });
    const fila = gpsTabela_(base, 'fila').registros;
    const ids = new Set(fila.map(r => r.id));
    const novos = [];
    for (const entrada of entradas) {
      if (ids.has(entrada.id)) continue;
      ids.add(entrada.id);
      novos.push({ ...entrada, status: 'pendente', tentativas: 0 });
    }
    gpsAnexar_(base, 'fila', novos);
    SpreadsheetApp.flush();
    props.setProperty(chave, JSON.stringify(pagina.proximo));
    const pendentes = gpsTabela_(base, 'fila').registros.filter(r => ['pendente', 'repetir'].includes(r.status));
    for (const item of pendentes.slice(0, 2)) {
      const tentativas = Number(item.tentativas) + 1;
      let status;
      try {
        status = gpsImportarItemFila_(base, item);
      } catch {
        status = tentativas >= 3 ? 'erro' : 'repetir';
      }
      gpsAuditar_(base, 'fila', item.id, status + ':' + tentativas, 'automacao');
      gpsAtualizarEstado_(base, 'fila', item, { ...item, tentativas, status });
      SpreadsheetApp.flush();
    }
    const enviar = props.getProperty('GPS_LAB_EMAIL') === 'true'
      ? (endereco, assunto, corpo) => MailApp.sendEmail(endereco, assunto, corpo) : null;
    gpsExecutarAlertas_(base, gpsHoje_(), enviar);
  });
}

function gpsConfigurarGatilhoLaboratorio_() {
  const props = PropertiesService.getScriptProperties();
  if (gpsModoDemonstracao_() || props.getProperty('GPS_LAB_AUTOMACAO') !== 'true') throw new Error('Automação de laboratório desabilitada');
  gpsComTrava_(() => {
    const existe = ScriptApp.getProjectTriggers().some(t => t.getHandlerFunction() === 'gpsSincronizarLaboratorio_');
    if (!existe) ScriptApp.newTrigger('gpsSincronizarLaboratorio_').timeBased().everyMinutes(5).create();
  });
}

// Reabre um erro confirmado no editor do projeto de laboratório, preservando o histórico.
function gpsReabrirErroFilaLaboratorio_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('GPS_LAB_REPROCESSAR_ID');
  if (gpsModoDemonstracao_() || !id || props.getProperty('GPS_LAB_AUTOMACAO') !== 'true') throw new Error('Reprocessamento indisponível');
  gpsComTrava_(() => {
    const base = gpsAbrirBase_();
    const item = gpsTabela_(base, 'fila').registros.find(r => r.id === id && r.status === 'erro');
    if (!item) throw new Error('Erro da fila indisponível');
    gpsAuditar_(base, 'fila', item.id, 'reaberto:' + item.tentativas, 'operador');
    gpsAtualizarEstado_(base, 'fila', item, { ...item, status: 'repetir' });
    SpreadsheetApp.flush();
    props.deleteProperty('GPS_LAB_REPROCESSAR_ID');
  });
}
function gpsFaixaGrafico_(iso, granularidade) {
  if (granularidade === 'ano') return iso.slice(0, 4);
  if (granularidade === 'mensal') return iso.slice(0, 7);
  if (granularidade === 'quinzenal') return iso.slice(0, 7) + (Number(iso.slice(8)) <= 15 ? ' / 1' : ' / 2');
  const data = new Date(iso + 'T00:00:00Z');
  data.setUTCDate(data.getUTCDate() - ((data.getUTCDay() + 6) % 7));
  return data.toISOString().slice(0, 10);
}

function gpsAgregarTerritorio_(escolas, atividades, filtro) {
  const apenasEscolas = escolas.filter(r => (!filtro.escola_id || r.id === filtro.escola_id) &&
    (!filtro.municipio_id || r.municipio_id === filtro.municipio_id));
  const pontos = new Map(apenasEscolas.map(r => {
    const latitude = r.latitude === '' || r.latitude == null ? null : Number(r.latitude);
    const longitude = r.longitude === '' || r.longitude == null ? null : Number(r.longitude);
    return [r.id, { id: r.id, nome: r.nome, latitude: Math.abs(latitude) <= 90 ? latitude : null,
      longitude: Math.abs(longitude) <= 180 ? longitude : null, previstas: 0, contabilizadas: 0, comprovadas: 0 }];
  }));
  const resumo = { previstas: 0, contabilizadas: 0, comprovadas: 0 };
  const periodos = new Map();
  const calor = new Map();
  for (const r of atividades) {
    if (!pontos.has(r.escola_id) || r.status === 'cancelada' || r.data < filtro.inicio || r.data > filtro.fim ||
        (filtro.pec_id && r.pec_id !== filtro.pec_id) || (filtro.pasta_id && r.pasta_id !== filtro.pasta_id) ||
        (filtro.tipo && r.tipo !== filtro.tipo)) continue;
    const periodo = gpsFaixaGrafico_(r.data, filtro.granularidade);
    const celula = gpsChave_(r.escola_id, periodo);
    if (!periodos.has(periodo)) periodos.set(periodo, { periodo, previstas: 0, contabilizadas: 0, comprovadas: 0 });
    if (!calor.has(celula)) calor.set(celula, { escola_id: r.escola_id, periodo, previstas: 0, contabilizadas: 0, comprovadas: 0 });
    for (const total of [resumo, pontos.get(r.escola_id), periodos.get(periodo), calor.get(celula)]) {
      total.previstas++;
      if (r.contabilizada) total.contabilizadas++;
      if (r.comprovada) total.comprovadas++;
    }
  }
  return { resumo, pontos: [...pontos.values()], periodos: [...periodos.values()].sort((a, b) => a.periodo.localeCompare(b.periodo)),
    calor: [...calor.values()] };
}

function gpsDadosTerritorio(filtro) {
  const { base, perfil } = gpsSessao_();
  if (!filtro || !gpsDataValida_(filtro.inicio) || !gpsDataValida_(filtro.fim) || filtro.fim < filtro.inicio ||
      Date.parse(filtro.fim) - Date.parse(filtro.inicio) > 366 * 86400000 ||
      !['semanal', 'quinzenal', 'mensal', 'ano'].includes(filtro.granularidade) ||
      !['', 'visita', 'apoio'].includes(filtro.tipo)) throw new Error('Filtro inválido');
  const hoje = gpsHoje_();
  const escopo = perfil.papel === 'CEC' ? '' : perfil.pec_id;
  const consulta = { ...filtro, pec_id: perfil.papel === 'AT' ? '' : escopo || filtro.pec_id,
    pasta_id: perfil.papel === 'AT' ? '' : filtro.pasta_id };
  const visiveis = gpsEscopoEscolas_(base, perfil);
  const chave = 'territorio:' + Utilities.base64EncodeWebSafe(Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256, JSON.stringify([base.getId(), perfil.papel, escopo, hoje, consulta, visiveis ? [...visiveis].sort() : null])));
  const cache = CacheService.getScriptCache();
  const hit = cache.get(chave);
  if (hit) return JSON.parse(hit);
  const escolas = gpsTabela_(base, 'escolas').registros.filter(r => !visiveis || visiveis.has(r.id));
  const atividades = gpsAtividadesBase_(base, hoje).filter(r => !escopo || r.pec_id === escopo);
  const dados = gpsAgregarTerritorio_(escolas, atividades, consulta);
  const json = JSON.stringify(dados);
  if (Utilities.newBlob(json).getBytes().length < 95000) cache.put(chave, json, 30);
  return dados;
}

function gpsOpcoesTerritorio() {
  const { base, perfil } = gpsSessao_();
  const escopo = perfil.papel === 'CEC' ? '' : perfil.pec_id;
  const atribuicoes = escopo ? gpsTabela_(base, 'atribuicoes').registros.filter(r => r.pec_id === escopo) : [];
  const ids = campo => new Set(atribuicoes.map(r => r[campo]));
  const escolasIds = gpsEscopoEscolas_(base, perfil);
  const escolas = gpsTabela_(base, 'escolas').registros.filter(r => !escolasIds || escolasIds.has(r.id));
  const municipios = new Set(escolas.map(r => r.municipio_id));
  const pastas = ids('pasta_id');
  const opcoes = registros => registros.map(({ id, nome }) => ({ id, nome }));
  return {
    hoje: gpsHoje_(), escolas: opcoes(escolas),
    municipios: opcoes(gpsTabela_(base, 'municipios').registros.filter(r => !escolasIds || municipios.has(r.id))),
    pecs: perfil.papel === 'AT' ? [] : opcoes(gpsTabela_(base, 'pecs').registros.filter(r => !escopo || r.id === escopo)),
    pastas: perfil.papel === 'AT' ? [] : opcoes(gpsTabela_(base, 'pastas').registros.filter(r => !escopo || pastas.has(r.id)))
  };
}

// Execute no editor de laboratório com um CSV autorizado na pasta privada do laboratório.
function gpsCarregarCadastroTerritorial_() {
  const id = PropertiesService.getScriptProperties().getProperty('GPS_LAB_CADASTRO_CSV_ID');
  if (!id) throw new Error('Configure o CSV de cadastro territorial');
  const doc = gpsLerArquivoLaboratorio_(id);
  if (!doc.grades || doc.grades.length !== 1) throw new Error('Cadastro deve ser um CSV');
  const cadastro = gpsCadastroTerritorial_(doc.grades[0]);
  gpsComTrava_(() => {
    const base = gpsAbrirBase_();
    gpsAnexar_(base, 'municipios', cadastro.municipios);
    gpsAnexar_(base, 'escolas', cadastro.escolas);
    gpsAuditar_(base, 'escolas', 'cadastro_territorial', 'importacao', 'operador');
  });
}

function gpsCadastroTerritorial_(grade) {
  const colunas = { codigo: ['codigo_seduc'], nome: ['escola'], municipio: ['municipio'],
    latitude: ['latitude'], longitude: ['longitude'] };
  const cabecalhos = gpsDetectarCabecalho_(grade, colunas);
  if (cabecalhos.length !== 1) throw new Error('Cabeçalho territorial indeterminado');
  const { linha, campos } = cabecalhos[0];
  const municipios = new Map();
  const escolas = new Map();
  for (const r of grade.slice(linha + 1)) {
    if (!r.some(valor => String(valor ?? '').trim())) continue;
    const ler = campo => String(r[campos[campo]] ?? '').trim();
    const codigo = ler('codigo');
    const nome = ler('nome');
    const municipio = ler('municipio');
    const latitude = Number(ler('latitude').replace(',', '.'));
    const longitude = Number(ler('longitude').replace(',', '.'));
    if (!/^[\d]+$/.test(codigo) || !nome || !municipio || !ler('latitude') || !ler('longitude') ||
        !Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180 ||
        escolas.has(codigo)) throw new Error('Registro territorial ausente ou duplicado');
    const municipio_id = gpsChave_('municipio', gpsNormalizar_(municipio));
    if (!municipios.has(municipio_id)) municipios.set(municipio_id, { id: municipio_id, nome: municipio });
    escolas.set(codigo, { id: codigo, codigo, nome, municipio_id, latitude, longitude });
  }
  if (!escolas.size) throw new Error('Cadastro territorial vazio');
  return { municipios: [...municipios.values()], escolas: [...escolas.values()] };
}
function doGet() {
  let acesso;
  try {
    acesso = gpsSessao_();
  } catch {
    return HtmlService.createHtmlOutput('<main><h1>Acesso restrito</h1><p>Entre com uma conta autorizada para a demonstração. Se o problema persistir, peça ao responsável que revise a instalação e seu acesso.</p></main>')
      .setTitle('GPS Pedagógico 2.0').addMetaTag('viewport', 'width=device-width, initial-scale=1');
  }
  const pagina = HtmlService.createTemplateFromFile('Painel');
  pagina.papel = acesso.perfil.papel;
  pagina.demonstracao = gpsModoDemonstracao_();
  return pagina.evaluate().setTitle('GPS Pedagógico 2.0').addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

const GPS_PAINEL = {
  indicadores: { titulo: 'Indicadores', campos: ['id', 'fonte', 'ano', 'escola_id', 'serie', 'metrica', 'escala', 'valor_original', 'valor', 'farol', 'revisar'] },
  obrigacoes_documentais: { titulo: 'Regularidade documental', campos: ['tipo', 'prazo', 'entrega', 'regularidade'] },
  revisoes: { titulo: 'Revisões documentais', campos: ['documento_id', 'motivo', 'status'] },
  escolas: { titulo: 'Escolas', campos: ['nome', 'codigo', 'municipio_id'] },
  municipios: { titulo: 'Municípios', campos: ['nome'] },
  pecs: { titulo: 'PECs', campos: ['nome'] },
  prioridades: { titulo: 'Prioridades', campos: ['escola_id', 'serie', 'turma_id', 'componente_id', 'ano', 'diagnostico', 'direcionamento', 'evidencias'] },
  alertas: { titulo: 'Alertas', campos: ['tipo', 'criticidade', 'status'] },
  visitas: { titulo: 'Visitas', campos: ['data', 'escola_id', 'status'] },
  apoios: { titulo: 'Apoios', campos: ['data', 'escola_id', 'status'] },
  metas: { titulo: 'Metas', campos: ['atividade', 'periodicidade', 'quantidade', 'obrigatoria'] }
};

function gpsPodeVer_(perfil, tabela, registro) {
  if (perfil.papel === 'CEC') return true;
  if (perfil.papel === 'AT') {
    if (tabela === 'escolas') return perfil.escolas?.has(registro.id) === true;
    return ['visitas', 'apoios'].includes(tabela) && perfil.escolas?.has(registro.escola_id) === true;
  }
  if (perfil.papel !== 'PEC' || !perfil.pec_id) return false;
  if (['visitas', 'apoios'].includes(tabela)) return registro.pec_id === perfil.pec_id;
  if (tabela === 'obrigacoes_documentais') return registro.pec_id === perfil.pec_id;
  if (tabela === 'alertas') return registro.destinatario_id === perfil.pec_id;
  return false;
}

function gpsCarregarPainel(tabela, cursor) {
  if (!Object.prototype.hasOwnProperty.call(GPS_PAINEL, tabela) ||
      !Number.isSafeInteger(cursor) || cursor < 0) throw new Error('Consulta inválida');
  const { base: planilha, perfil } = gpsSessao_();
  const camposVisiveis = GPS_PAINEL[tabela].campos.map(gpsRotuloCampo_);
  const permitidas = perfil.papel === 'AT' ? ['escolas', 'visitas', 'apoios'] : ['visitas', 'apoios', 'alertas', 'obrigacoes_documentais'];
  if (perfil.papel !== 'CEC' && !permitidas.includes(tabela)) {
    return { titulo: GPS_PAINEL[tabela].titulo, campos: camposVisiveis, linhas: [], proximo: null };
  }
  const nomes = gpsNomesPainel_(planilha, tabela);
  if (tabela === 'prioridades') {
    const { titulo, campos } = GPS_PAINEL.prioridades;
    const hoje = gpsHoje_();
    const prioridades = gpsPrioridadesBase_(planilha, Number(hoje.slice(0, 4)));
    const acompanhamento = new Map(gpsMonitorarPrioridades_(prioridades, gpsAtividadesBase_(planilha, hoje))
      .map(r => [r.prioridade_id, r]));
    const linhas = prioridades.slice(cursor, cursor + 100).map(r => {
      const dados = { ...r, ...acompanhamento.get(r.id) };
      return campos.map(campo => gpsValorPainel_(dados, campo, nomes));
    });
    return { titulo, campos: camposVisiveis, linhas, proximo: cursor + 100 < prioridades.length ? cursor + 100 : null };
  }
  if (tabela === 'obrigacoes_documentais') {
    const hoje = gpsHoje_();
    const autorizadas = gpsTabela_(planilha, tabela).registros.filter(r => gpsPodeVer_(perfil, tabela, r));
    const linhas = autorizadas.slice(cursor, cursor + 100).map(r => {
      const situacao = gpsSituacaoDocumento_(r, hoje);
      return [gpsValorPainel_(r, 'tipo', {}), r.prazo || '—', r.entrega || '—', { texto: situacao.situacao, cor: situacao.cor }];
    });
    return { titulo: GPS_PAINEL[tabela].titulo, campos: camposVisiveis, linhas,
      proximo: cursor + 100 < autorizadas.length ? cursor + 100 : null };
  }
  if (perfil.papel === 'AT') perfil.escolas = gpsEscopoEscolas_(planilha, perfil);
  const aba = planilha.getSheetByName(tabela);
  const ultimaLinha = aba.getLastRow();
  const inicio = cursor + 2;
  const quantidade = Math.max(0, Math.min(100, ultimaLinha - inicio + 1));
  const colunas = ['id', ...GPS_SCHEMA[tabela]];
  const campos = GPS_PAINEL[tabela].campos;
  const intervalo = quantidade ? aba.getRange(inicio, 1, quantidade, colunas.length) : null;
  const regrasFarol = tabela === 'indicadores' ? gpsTabela_(planilha, 'farois').registros : [];
  const brutos = tabela === 'indicadores' && intervalo ? intervalo.getValues() : [];
  const valores = intervalo ? intervalo.getDisplayValues() : [];
  const linhas = valores.map((linha, j) => ({
    ...Object.fromEntries(colunas.map((campo, i) => [campo, linha[i]])),
    farolValidado: brutos[j]?.[colunas.indexOf('revisar')] === false,
    nivel: linha[colunas.indexOf('nivel')]
  }))
    .filter(registro => registro.id && gpsPodeVer_(perfil, tabela, registro))
    .map(registro => campos.map(campo => campo === 'farol' ? gpsFarolIndicador_(registro, regrasFarol) : gpsValorPainel_(registro, campo, nomes)));
  return {
    titulo: GPS_PAINEL[tabela].titulo, campos: camposVisiveis, linhas,
    proximo: inicio + quantidade <= ultimaLinha ? cursor + quantidade : null
  };
}

function gpsSessao_() {
  const email = Session.getActiveUser().getEmail().trim().toLowerCase();
  if (!email) throw new Error('Acesso ao laboratório indisponível');
  const base = gpsAbrirBase_();
  const candidatos = gpsTabela_(base, 'usuarios').registros.filter(item => String(item.email).trim().toLowerCase() === email);
  const usuario = candidatos[0];
  if (candidatos.length !== 1 || usuario.ativo !== true ||
      !['CEC', 'PEC', 'AT'].includes(usuario.perfil) || (usuario.perfil === 'PEC' && !usuario.pec_id)) {
    throw new Error('Acesso ao laboratório indisponível');
  }
  return { base, perfil: { papel: usuario.perfil, pec_id: usuario.perfil === 'AT' ? '' : usuario.pec_id, id: usuario.id } };
}

function gpsHoje_() {
  return Utilities.formatDate(new Date(), 'America/Sao_Paulo', 'yyyy-MM-dd');
}

function gpsIncluir_(arquivo) {
  return HtmlService.createHtmlOutputFromFile(arquivo).getContent();
}


function gpsEscopoEscolas_(base, perfil) {
  if (perfil.papel === 'CEC') return null;
  const vinculos = perfil.papel === 'AT'
    ? gpsTabela_(base, 'escopos_at').registros.filter(r => r.usuario_id === perfil.id)
    : gpsTabela_(base, 'atribuicoes').registros.filter(r => r.pec_id === perfil.pec_id);
  return new Set(vinculos.map(r => r.escola_id));
}

function gpsFarolIndicador_(registro, regras) {
  const valor = String(registro.valor ?? '').trim();
  if (!registro.farolValidado) return { texto: valor ? 'Em revisão' : 'Sem dado', cor: 'cinza' };
  if (!valor) return { texto: 'Sem dado', cor: 'cinza' };
  const nivel = String(registro.nivel ?? '').trim();
  const niveisPP = ['Abaixo do Básico', 'Básico', 'Adequado', 'Avançado'];
  const nivelAceito = nivel && (registro.fonte !== 'prova_paulista' || niveisPP.includes(nivel));
  const correspondencias = nivelAceito ? regras.filter(r => r.homologado === true && r.referencia &&
    r.fonte === registro.fonte && String(r.ano) === String(registro.ano) && r.escala === registro.escala &&
    r.metrica === registro.metrica && r.nivel === nivel && ['vermelho', 'amarelo', 'verde', 'azul'].includes(r.cor)) : [];
  const regra = correspondencias.length === 1 ? correspondencias[0] : null;
  return { texto: regra ? nivel : valor, cor: regra ? regra.cor : 'cinza' };
}

function gpsRotuloCampo_(campo) {
  const rotulos = { id: 'Identificador', nome: 'Nome', codigo: 'Código', municipio_id: 'Município',
    escola_id: 'Escola', turma_id: 'Turma', componente_id: 'Componente curricular', fonte: 'Avaliação',
    ano: 'Ano', serie: 'Ano ou série', metrica: 'Indicador', escala: 'Escala', valor_original: 'Valor na fonte',
    valor: 'Valor conferido', farol: 'Farol', revisar: 'Revisão necessária', diagnostico: 'Diagnóstico',
    direcionamento: 'Direcionamento', evidencias: 'Evidências', documento_id: 'Identificador do documento',
    prazo: 'Prazo', entrega: 'Entrega', regularidade: 'Regularidade', motivo: 'Motivo', status: 'Situação', tipo: 'Tipo', criticidade: 'Criticidade', data: 'Data',
    atividade: 'Atividade', periodicidade: 'Periodicidade', quantidade: 'Quantidade', obrigatoria: 'Obrigatória' };
  return rotulos[campo] || campo;
}

function gpsNomesPainel_(base, tabela) {
  const nomes = {};
  const cadastros = { escola_id: 'escolas', municipio_id: 'municipios', turma_id: 'turmas', componente_id: 'componentes' };
  for (const campo of GPS_PAINEL[tabela].campos) {
    if (!cadastros[campo]) continue;
    nomes[campo] = new Map(gpsTabela_(base, cadastros[campo]).registros.map(r => [String(r.id), r.nome || r.codigo]));
  }
  return nomes;
}

function gpsValorPainel_(registro, campo, nomes) {
  const valor = registro[campo] ?? '';
  if (nomes[campo]) return valor ? nomes[campo].get(String(valor)) || 'Cadastro indisponível' : '—';
  const rotulos = { saresp: 'SARESP', saeb: 'SAEB', prova_paulista: 'Prova Paulista', avd: 'Avaliação Diagnóstica',
    frequencia: 'Frequência', participacao: 'Participação', proficiencia: 'Proficiência', percentual_nivel: 'Percentual no nível',
    aguardando_comprovacao: 'Aguardando comprovação', sem_historico_escolar: 'Sem histórico escolar',
    sem_planejamento: 'Sem planejamento', sem_evidencia_documental: 'Sem evidência documental', termo_pendente: 'Termo pendente',
    prioridade_nao_contemplada: 'Prioridade não contemplada', meta_nao_atingida: 'Meta não atingida' };
  return ['fonte', 'metrica', 'status', 'tipo', 'diagnostico', 'direcionamento', 'evidencias', 'motivo'].includes(campo)
    ? rotulos[valor] || String(valor).replaceAll('_', ' ') : valor;
}
